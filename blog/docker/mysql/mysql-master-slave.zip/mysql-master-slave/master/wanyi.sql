create database wanyi;
use wanyi;

DROP TABLE IF EXISTS `wanyi`;
CREATE TABLE `wanyi` (
  `id` int(11) NOT NULL COMMENT 'id',
  `name` varchar(32) NOT NULL COMMENT '姓名',
  PRIMARY KEY (`id`) USING BTREE
)ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='test for mysq-master-slave';

INSERT INTO `wanyi` VALUES (1,"万一");
INSERT INTO `wanyi` VALUES (2,"万二");
INSERT INTO `wanyi` VALUES (3,"万三");
